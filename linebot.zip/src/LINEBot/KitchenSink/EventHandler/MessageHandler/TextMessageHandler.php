<?php

/**
 * Copyright 2016 LINE Corporation
 *
 * LINE Corporation licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

namespace LINE\LINEBot\KitchenSink\EventHandler\MessageHandler;

use LINE\LINEBot;
use LINE\LINEBot\Event\MessageEvent\TextMessage;
use LINE\LINEBot\KitchenSink\EventHandler;
use Predis\Client;
use LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder;
use LINE\LINEBot\TemplateActionBuilder\UriTemplateActionBuilder;
use LINE\LINEBot\TemplateActionBuilder\PostbackTemplateActionBuilder;

class TextMessageHandler implements EventHandler
{
    /** @var LINEBot $bot */
    private $bot;
    /** @var \Monolog\Logger $logger */
    private $logger;
    /** @var \Slim\Http\Request $logger */
    private $req;
    /** @var TextMessage $textMessage */
    private $textMessage;

    private $redis;
    /**
     * TextMessageHandler constructor.
     * @param $bot
     * @param $logger
     * @param \Slim\Http\Request $req
     * @param TextMessage $textMessage
     */
    public function __construct($bot, $logger, \Slim\Http\Request $req, TextMessage $textMessage)
    {
        $this->bot = $bot;
        $this->logger = $logger;
        $this->req = $req;
        $this->textMessage = $textMessage;
        $this->redis = new Client(getenv('REDIS_URL'));
    }

    public function handle()
    {
        $TEACH_SIGN = '==';
        $DEL_KEY ='!_=';
        $DEL_SIGH = '=!=';
        $text = $this->textMessage->getText();
        $text = trim($text);
        # Remove ZWSP
        $text = str_replace("\xE2\x80\x8B", "", $text);
        $replyToken = $this->textMessage->getReplyToken();

        if ($text == 'สอนน้องโปรจา') {
            $this->bot->replyText($replyToken, $out =
                "เพื่อนๆสามารถใช้" . $TEACH_SIGN . "ในการสอนน้องโปรจาได้เช่น \n  'สวัสดี==ดีจ้า'  ");
            return true;
        }

        if ($text == 'Syntax') {
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("If-Statement", "If-Statement"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Switch", "switch"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Looping Statement", "loop"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Scanner", "scanner")

                          );
            $img_url = 'https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363';
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Java Syntax", "Basic Java Programming Syntax", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);

            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }

        if ($text == 'Data') {
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Variable", "variable"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Data-type", "data-type"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Attribute", "attribute"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Modifier", "modifier")


            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Data", "Data in Java Programming", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);

            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }

        if ($text == 'array-menu') {
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Array", "array"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("2D-Array", "2d-array"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Arraylist", "arraylist")
            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Array", "Array in java", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);
            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }

        if ($text == 'ClassandScope') {
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Class", "class"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Getter-Setter", "get-set")

            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Class", "Class and Scope in Java", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);
            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }

        if($text == 'If-Statement'){
             $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("If-If", "if-if"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("If-Else", "if-else"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("If-Else-If", "if-else-if")

            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("If Syntax", "If-Statement", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);
            $this->bot->replyMessage($replyToken, $outputText);
            return true;

        }

        if($text == 'if-if'){
            $text1 = "ตัวอย่าง if-if";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/f1bb64795ded0ecf9411eadcbe2f6bbd.jpg";
            $img_url2 = "https://www.img.in.th/images/78bd1557a19f417af08f1ca8a2a5e0d7.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'if-else'){
            $text1 = "ตัวอย่าง if-else";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/f6645bbed23b190b8ff0a97f12716028.jpg";
            $img_url2 = "https://www.img.in.th/images/9824ba017fbc9a74b1e47298a7dbe888.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'if-else-if'){
            $text1 = "ตัวอย่าง if-else-if";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/d56698d46bd220a1087e8b7c561a6c2a.jpg";
            $img_url2 = "https://www.img.in.th/images/848968ab08aed2bbc3bf2c9d8480415a.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'switch'){
            $text1 = "ตัวอย่าง Switch-Case";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/e1bc14431de1e2a3f20f5110c1358626.jpg";
            $img_url2 = "https://www.img.in.th/images/223eb7fc6e549d5f8ce1237b01011017.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'loop'){
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("For-Loop", "for-loop"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("While-Loop", "while-loop"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Do-While-Loop", "do-while-loop")

            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Loop Syntax", "Looping Statement", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);
            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }

        if($text == 'for-loop'){
            $text1 = "ตัวอย่าง For-Loop";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/b455af7fea0ce109921c7ce13768ee2a.jpg";
            $img_url2 = "https://www.img.in.th/images/e821fafd71fdd4a40f9adac993c3bbfd.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'while-loop'){
            $text1 = "ตัวอย่าง while-loop";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/87513d2e52520573138f3315c0587beb.jpg";
            $img_url2 = "https://www.img.in.th/images/e821fafd71fdd4a40f9adac993c3bbfd.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'do-while-loop'){
            $text1 = "ตัวอย่าง do-while-loop";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/3d8b954c8e3378dd59f6964b01b974a3.jpg";
            $img_url2 = "https://www.img.in.th/images/e821fafd71fdd4a40f9adac993c3bbfd.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'scanner'){
            $text1 = "ตัวอย่าง Scanner";
            $text2 = "ผลลัพธ์";

            $img_url1 = "https://www.img.in.th/images/848f193cdf75c994198cdf8f34d4037d.jpg";
            $img_url2 = "https://www.img.in.th/images/c9e42b889b6a12df996e10fa56369d4b.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'variable'){
            $text1 = "Variable คือตัวแปรต่างๆที่สร้างมาเก้บข้อมูล";
            $text2 = "Variable จะอยู่ใน Method ต่างๆ";
            $text3 = "สามารถสร้างได้ดังนี้";

            $img_url1 = "https://www.img.in.th/images/b46958636ffddb21ec50d910de7831ef.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));


            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'data-type'){
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Integral", "int"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Floating", "float"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Boolean", "boolean"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Char and String", "text")

            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Loop Syntax", "Looping Statement", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);
            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }

        if($text == 'int'){
            $text1 = "Integral คือตัวแปรจำนวนเต็ม";
            $text2 = "ชนิดต่างๆและขนาดของตัวแปร";

            $img_url1 = "https://www.img.in.th/images/bbc3d6a20e537a8e533ed1cac803b395.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'float'){
            $text1 = "floating คือตัวแปรเลขทศนิยม";
            $text2 = "ชนิดต่างๆและขนาดของตัวแปร";

            $img_url1 = "https://www.img.in.th/images/bd8f4cdd7cf33986753948a69723c6e7.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'boolean'){
            $text1 = "Booleanคือตัวแปรที่เก็บตรรกะถูกหรือผิด";
            $text2 = "ชนิดต่างๆและขนาดของตัวแปร";

            $img_url1 = "https://www.img.in.th/images/077735fdb58a53df2b000c244df78069.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'text'){
            $text1 = "Text มีสองแบบ Char กับ String";
            $text2 = "Char เก็บตัวอักษร";
            $text3 = "String เก็บเป็นข้อความ";
            $img_url1 = "https://www.img.in.th/images/815eb15f0a812877f715e73a0eeee788.jpg";
            $img_url2 = "https://www.img.in.th/images/b56a6d506352249f308555f629888b05.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }


        if($text == 'attribute'){
            $text1 = "ตัวอย่างการสร้าง Attribute";
            $text2 = "Variable ไม่สามารถใช้นอก method ได้";
            $text3 ="แต่ Attribute สามารถนำไปใน method ได้";
            $img_url1 = "https://www.img.in.th/images/6b28773b3eecf7d17d4841ad5eb66a10.jpg";
            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'modifier'){
            $text1 = "Modifier คือตัวควบคุมการเข้าถึง";
            $text2 = "มีทั้งหมด 4 ประเภท";
            $text4 ="การสร้างAttributeที่มี modifier";
            $img_url1 = "https://www.img.in.th/images/12f821aeb58fd67538e3b7f1005f7d2d.jpg";
            $img_url2 = "https://www.img.in.th/images/17a910f90de5fc7df7ac24ba0d14f2ed.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text4))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'array'){
            $text1 = "Array คือการเก็บข้อมูล";
            $text2 = "ในรูปแบบของเซ็ต";
            $text3 = "ข้อมูลใน Array ต้องมีชนิดเดียวกัน";
            $text4 = "ตัวอย่างการใช้ Array";
            $img_url1 = "https://www.img.in.th/images/49b167d36f6eb6128f95f2c408209ee6.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text4))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == '2d-array'){
            $text1 = "Array คือการเก็บข้อมูล";
            $text2 = "ในรูปแบบของตาราง";
            $text3 = "ข้อมูลใน Array ต้องมีชนิดเดียวกัน";
            $text4 = "ตัวอย่างการใช้ Array 2 มิติ";
            $img_url1 = "https://www.img.in.th/images/8e76d5685f930e6e1242c55ccfb6ca57.jpg";
            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text4))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'arraylist'){
            $text1 = "ArrayList เป็น Class ";
            $text2 = "ที่เอาไว้เก็บข้อมูลในรูปแบบของ Array ";
            $text3 = "ข้อมูลใน Array มีหลายชนิดได้";
            $text4 = "ตัวอย่างการใช้ Arraylist";
            $img_url1 = "https://www.img.in.th/images/feefea54d04198985e13fce3c5693b1b.jpg";
            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text4))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;

        }

        if($text == 'class'){
            $text1 = "องค์ประกอบของ Class";
            $text2 = "ตัวอย่างของ Class";
            $img_url1 = "https://www.img.in.th/images/ac6529f0086915a0c4ea9a7616323570.jpg";
            $img_url2 = "https://www.img.in.th/images/e2059b35bae704696040b32c4be7a239.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }

        if($text == 'get-set'){
            $actions = array (
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Getter", "get-method"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Setter", "set-method"),
              New \LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder("Use get-set", "use-get-set")
            );
            $img_url = "https://cdn.shopify.com/s/files/1/0379/7669/products/sampleset2_1024x1024.JPG?v=1458740363";
            $button = new \LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder("Get-Set Method", "Get-Set Method", $img_url, $actions);
            $outputText = new \LINE\LINEBot\MessageBuilder\TemplateMessageBuilder("Button template builder", $button);
            $this->bot->replyMessage($replyToken, $outputText);
            return true;
        }
        if($text == 'get-method'){
            $text1 = "Method get จะเป็น Method ที่มี";
            $text2 = "ชนิดเดียวกับ Attribute ";
            $text3 = "มีการ return ค่า โดยมี datatype";
            $text4 = "เหมือนกับ Attribute และ Method";
            $img_url1 = "https://www.img.in.th/images/26386b1042a253525c11e45a6adb20d5.jpg";
            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text4))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }
        if($text == 'set-method'){
            $text1 = "Method set เป็นแบบ void";
            $text2 = "จะต้องมี Parameter ที่รับมา";
            $text3 = "เพื่อนำมา set ค่าให้กับ Attribute";
            $img_url1 = "https://www.img.in.th/images/4c5824f3b6a080abbcecdfd5eadffb14.jpg";

            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text3))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }
        if($text == 'use-get-set'){
            $text1 = "ตัวอย่างการสร้าง get-set Method ";
            $img_url1 = "https://www.img.in.th/images/d960336234db099045a0ab97f3f07eef.jpg";
            $text2 = "การเรียกใช้ get-set Method";
            $img_url2 = "https://www.img.in.th/images/1cf6a3e244b52259880caa48a20cc226.jpg";
            $img_url3 = "https://www.img.in.th/images/17d1b20c676240c1818677b989a92329.jpg";
            $multipleMessageBuilder = new \LINE\LINEBot\MessageBuilder\MultiMessageBuilder();
            $multipleMessageBuilder->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text1))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url1, $img_url1))
                        ->add(new \LINE\LINEBot\MessageBuilder\TextMessageBuilder($text2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url2, $img_url2))
                        ->add(new \LINE\LINEBot\MessageBuilder\ImageMessageBuilder($img_url3, $img_url3));
            $multipleMessageBuilder->buildMessage();
            $this->bot->replyMessage($replyToken, $multipleMessageBuilder);
            return true;
        }
        $sep_pos = strpos($text, $TEACH_SIGN);
        $del_pos = strpos($text,$DEL_SIGH);
        $del_pos_key = strpos($text,$DEL_KEY);

        if($del_pos_key > 0){
            $size=$this->getSize($text_arr[0]);
            for ($i=0; $i <$size ; $i++) {
              $this->delElement($text_arr[0]);
            }
        }

        if ($sep_pos > 0) {
            $text_arr = explode($TEACH_SIGN, $text, 2);
            if (count($text_arr) == 2) {
                $this->saveResponse($text_arr[0], $text_arr[1]);
            }
            return true;
        }
        if ($del_pos > 0) {
            $text_arr = explode($DEL_SIGH, $text, 2);
            if (count($text_arr) == 2) {
                $this->delResponse($text_arr[0], $text_arr[1]);
            }
            return true;
        }

        else{
            $re = $this->getResponse($text);
            $re_count = count($re);
            if ($re_count > 0) {
                $randNum = rand(0, $re_count - 1);
                $response = $re[$randNum];
                $this->bot->replyText($replyToken, $response);
                return true;
            }

        }

        return false;
    }

    private function getSize($keyword)
    {
        return $this->redis->lsize("response:$keyword");
    }

    private function delElement($keyword)
    {
        $this->redis->lpop("response:$keyword");
    }

    private function delResponse($keyword, $response)
    {
        $this->redis->lrem("response:$keyword", 0,$response);
    }

    private function saveResponse($keyword, $response)
    {
        $this->redis->lpush("response:$keyword", $response);
    }

    private function getResponse($keyword)
    {
        return $this->redis->lrange("response:$keyword", 0, -1);
    }
}
